/*
 * Create a function that inputs two numbers and the final result to use fibonacci
*/

// Function the counts from 1 to the input number and prints it




//Initiates the function
function fibonacci(x, y, count) {

  let res;

  document.writeln(x, "<br>");
  document.writeln(y,"<br>");

  for (i = 1; i <= count; i++) {
    res = x + y;
    x = y;
    y = res;
    document.writeln(res + "<br>");
  }
}

function promptInt(string) {
  let input = prompt(string);
  return parseInt(input);
}

fibonacci(promptInt("Introduce un numero: "), promptInt("Introduce otro numero: "), promptInt("Introduce el numero final: "))
