let age;

age = parseInt(prompt("What's your age: "));


if (age < 18)
{
  alert("You are not 18 yet");
} else if (age >= 18)
{
  alert("You are 18 or older");
}
