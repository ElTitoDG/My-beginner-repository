/* Basic version of the script
count = parseInt(prompt("Input a number: "));

for (i = 1; i <= count; i++)
{
  alert("Number: " + i);
}
*/



function count(count)
{
  //count = parseInt(prompt("Input a number: "));

  opc = confirm("ACCEPT to use alerts and CANCEL to print on document");

  if(opc == true)
  {
    for (i = 1; i <= count; i++)
    {
      alert("Number: " + i);
    }
  } else
  {
    for (i = 1; i <= count; i++)
    {
      document.writeln("Number: " + i + "<br>");
    }
  }


}

count(prompt("Input number: "));
